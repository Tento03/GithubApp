package com.example.tes.api

data class UserResponse(var items:List<User>) {
}
